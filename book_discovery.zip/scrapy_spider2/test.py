from subprocess import call


import pickle

import json

import os

import os.path
from os import path

from os import getcwd

print(getcwd())





#list_url = ['http://nymag.com/strategist/article/best-personal-finance-books.html', 'https://www.thebalance.com/best-personal-finance-books-4154809', 'https://www.thewaystowealth.com/investing/best-investing-books/', 'https://www.cloudways.com/blog/best-startup-books-for-new-entrepreneurs/' ]

list_url = ['http://nymag.com/strategist/article/best-personal-finance-books.html']
with open('outfile', 'wb') as fp:
    pickle.dump(list_url, fp)

itemlist = []
with open ('outfile', 'rb') as fp:
    itemlist = pickle.load(fp)


print("item list is", itemlist)

path_file = getcwd() + "/ blogspider.json"

if path.exists(path_file):
    os.remove(path_file)

name = 'blogspider'
call(["scrapy", "crawl", "{0}".format(name), "-o {0}.json".format(name)])

with open(path_file) as json_file:
    data = json.load(json_file)
    print("data is", data[-1])
